package com.example.raspberryconnect_oldsdk.ui.home

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel

class HomeViewModel : ViewModel() {

    private val _text = MutableLiveData<String>().apply {
        value = "Operate Your Utilities"
    }
    val text: LiveData<String> = _text

    // Create LiveData variables to store the state of the switches and sensor TextViews
    private val _lumina1SwitchState = MutableLiveData<Boolean>()
    val lumina1SwitchState: LiveData<Boolean> = _lumina1SwitchState
    private val _lumina2SwitchState = MutableLiveData<Boolean>()
    val lumina2SwitchState: LiveData<Boolean> = _lumina2SwitchState
    private val _lumina3SwitchState = MutableLiveData<Boolean>()
    val lumina3SwitchState: LiveData<Boolean> = _lumina3SwitchState
    private val _lumina4SwitchState = MutableLiveData<Boolean>()
    val lumina4SwitchState: LiveData<Boolean> = _lumina4SwitchState
    private val _aerconditionatSwitchState = MutableLiveData<Boolean>()
    val aerconditionatSwitchState: LiveData<Boolean> = _aerconditionatSwitchState
    private val _senzorgazSwitchState = MutableLiveData<Boolean>()
    val senzorgazSwitchState: LiveData<Boolean> = _senzorgazSwitchState
    private val _senzorgazTextState = MutableLiveData<String>()
    val senzorgazTextState: LiveData<String> = _senzorgazTextState
    private val _senzortemperaturaTextState = MutableLiveData<String>()
    val senzortemperaturaTextState: LiveData<String> = _senzortemperaturaTextState
    private val _senzorumiditateTextState = MutableLiveData<String>()
    val senzorumiditateTextState: LiveData<String> = _senzorumiditateTextState
    private val _senzorproximitateTextState = MutableLiveData<String>()
    val senzorproximitateTextState: LiveData<String> = _senzorproximitateTextState

    // Update the state of the switches and sensor TextViews
    fun updateLumina1SwitchState(state: Boolean) {
        _lumina1SwitchState.value = state
    }

    fun updateLumina2SwitchState(state: Boolean) {
        _lumina2SwitchState.value = state
    }

    // Update the state of the switches and sensor TextViews
    fun updateLumina3SwitchState(state: Boolean) {
        _lumina3SwitchState.value = state
    }

    fun updateLumina4SwitchState(state: Boolean) {
        _lumina4SwitchState.value = state
    }

    fun updateAerconditionatSwitchState(state: Boolean) {
        _aerconditionatSwitchState.value = state
    }

    fun updateSenzorgazSwitchState(state: Boolean) {
        _senzorgazSwitchState.value = state
    }

    fun updateSenzorgazText(text: String) {
        _senzorgazTextState.value = text
    }

    fun updateSenzortemperaturaText(text: String) {
        _senzortemperaturaTextState.value = text
    }

    fun updateSenzorumiditateText(text: String) {
        _senzorumiditateTextState.value = text
    }

    fun updateSenzorproximitateText(text: String) {
        _senzorproximitateTextState.value = text
    }
}