package com.example.raspberryconnect_oldsdk.ui.home

import android.annotation.SuppressLint
import android.content.ContentValues.TAG
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.lifecycleScope
import com.example.raspberryconnect_oldsdk.AppGlobals
import com.example.raspberryconnect_oldsdk.SensorUpdater
import com.example.raspberryconnect_oldsdk.SshConnection
import com.example.raspberryconnect_oldsdk.databinding.FragmentHomeBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext

private lateinit var homeViewModel: HomeViewModel

class HomeFragment : Fragment() {

    private var _binding: FragmentHomeBinding? = null

    // This property is only valid between onCreateView and onDestroyView.
    private val binding get() = _binding!!

    private var sshConnection: SshConnection? = null
    private val sshConnectionMutex = Mutex()
    private var job: Job? = null

    @SuppressLint("StaticFieldLeak", "UseSwitchCompatOrMaterialCode")
    private lateinit var lumina1Switch: Switch
    @SuppressLint("StaticFieldLeak", "UseSwitchCompatOrMaterialCode")
    private lateinit var lumina2Switch: Switch
    @SuppressLint("StaticFieldLeak", "UseSwitchCompatOrMaterialCode")
    private lateinit var lumina3Switch: Switch
    @SuppressLint("StaticFieldLeak", "UseSwitchCompatOrMaterialCode")
    private lateinit var lumina4Switch: Switch
    @SuppressLint("StaticFieldLeak", "UseSwitchCompatOrMaterialCode")
    private lateinit var aerconditionatSwitch: Switch
    @SuppressLint("StaticFieldLeak", "UseSwitchCompatOrMaterialCode")
    private lateinit var senzorgazSwitch: Switch
    @SuppressLint("StaticFieldLeak")
    private lateinit var senzorgazText: TextView
    @SuppressLint("StaticFieldLeak")
    private lateinit var senzortemperaturaText: TextView
    @SuppressLint("StaticFieldLeak")
    private lateinit var senzorumiditateText: TextView
    @SuppressLint("StaticFieldLeak")
    private lateinit var senzorproximitateText: TextView

    companion object {
        const val COMMAND_ON = "op dh"
        const val COMMAND_OFF = "op dl"
    }

    // Use view binding to get references to views in the layout
    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        _binding = FragmentHomeBinding.inflate(inflater, container, false)
        val root: View = binding.root

        // Get a reference to the textHome TextView from the layout
        val textView: TextView = binding.textHome
        // Get references to the switches and sensor TextViews from the layout using view binding
        lumina1Switch = binding.lumina1Switch
        lumina2Switch = binding.lumina2Switch
        lumina3Switch = binding.lumina3Switch
        lumina4Switch = binding.lumina4Switch
        aerconditionatSwitch = binding.aerConditionatSwitch
        senzorgazSwitch = binding.SenzorGazSwitch
        senzorgazText = binding.SenzorGazText
        senzortemperaturaText = binding.SenzorTempText1
        senzorumiditateText = binding.SenzorUmidText1
        senzorproximitateText = binding.SenzorProxiText

        // Create an instance of the HomeViewModel using ViewModelProvider and observe the text LiveData
        homeViewModel = ViewModelProvider(this)[HomeViewModel::class.java]
        homeViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        homeViewModel.lumina1SwitchState.observe(viewLifecycleOwner) {
            lumina1Switch.isChecked = it
        }

        homeViewModel.lumina2SwitchState.observe(viewLifecycleOwner) {
            lumina2Switch.isChecked = it
        }

        homeViewModel.lumina3SwitchState.observe(viewLifecycleOwner) {
            lumina3Switch.isChecked = it
        }

        homeViewModel.lumina4SwitchState.observe(viewLifecycleOwner) {
            lumina4Switch.isChecked = it
        }

        homeViewModel.aerconditionatSwitchState.observe(viewLifecycleOwner) {
            aerconditionatSwitch.isChecked = it
        }

        homeViewModel.senzorgazSwitchState.observe(viewLifecycleOwner) {
            senzorgazSwitch.isChecked = it
        }

        homeViewModel.senzorgazTextState.observe(viewLifecycleOwner) {
            senzorgazText.text = it
        }

        homeViewModel.senzortemperaturaTextState.observe(viewLifecycleOwner) {
            senzortemperaturaText.text = it
        }

        homeViewModel.senzorumiditateTextState.observe(viewLifecycleOwner) {
            senzorumiditateText.text = it
        }

        homeViewModel.senzorproximitateTextState.observe(viewLifecycleOwner) {
            senzorproximitateText.text = it
        }

        // Check if the required fields have been entered in the AppGlobals object
        if (AppGlobals.hostName.isNotEmpty() && AppGlobals.ipAddress.isNotEmpty() && AppGlobals.password.isNotEmpty()) {
            // Set switch listeners to handle switching on/off of devices
            viewLifecycleOwner.lifecycleScope.launch {
                setSwitchListeners()
            }
        } else {
            // If required fields have not been entered, show a toast message to the user
            Toast.makeText(requireContext(), "Please enter all required fields", Toast.LENGTH_LONG)
                .show()
        }
        return root
    }

    // This function sets listeners for each switch in the UI
    private fun setSwitchListeners() {
        // Set listener for lumina1Switch
        lumina1Switch.setOnCheckedChangeListener { _, isChecked ->
            // If the switch is checked, set the value to "on", else "off"
            val value = if (isChecked) "on" else "off"
            // Launch a coroutine in the IO dispatcher to send the SSH command for the corresponding pin and value
            lifecycleScope.launch(Dispatchers.IO) {
                sendSshCommand(21, value)
            }
        }

        // Set listener for lumina2Switch
        lumina2Switch.setOnCheckedChangeListener { _, isChecked ->
            // If the switch is checked, set the value to "on", else "off"
            val value = if (isChecked) "on" else "off"
            // Launch a coroutine in the IO dispatcher to send the SSH command for the corresponding pin and value
            lifecycleScope.launch(Dispatchers.IO) {
                sendSshCommand(20, value)
            }
        }

        // Set listener for lumina1Switch
        lumina3Switch.setOnCheckedChangeListener { _, isChecked ->
            // If the switch is checked, set the value to "on", else "off"
            val value = if (isChecked) "on" else "off"
            // Launch a coroutine in the IO dispatcher to send the SSH command for the corresponding pin and value
            lifecycleScope.launch(Dispatchers.IO) {
                sendSshCommand(16, value)
            }
        }

        // Set listener for lumina2Switch
        lumina4Switch.setOnCheckedChangeListener { _, isChecked ->
            // If the switch is checked, set the value to "on", else "off"
            val value = if (isChecked) "on" else "off"
            // Launch a coroutine in the IO dispatcher to send the SSH command for the corresponding pin and value
            lifecycleScope.launch(Dispatchers.IO) {
                sendSshCommand(12, value)
            }
        }

        // Set listener for aerconditionatSwitch
        aerconditionatSwitch.setOnCheckedChangeListener { _, isChecked ->
            // If the switch is checked, set the value to "on", else "off"
            val value = if (isChecked) "on" else "off"
            // Launch a coroutine in the IO dispatcher to send the SSH command for the corresponding pin and value
            lifecycleScope.launch(Dispatchers.IO) {
                sendSshCommand(1, value)
            }
        }

        // Set listener for senzorgazSwitch
        senzorgazSwitch.setOnCheckedChangeListener { _, isChecked ->
            // If the switch is checked, set the value to "on", else "off"
            val value = if (isChecked) "off" else "on"
            // Launch a coroutine in the IO dispatcher to send the SSH command for the corresponding pin and value
            lifecycleScope.launch(Dispatchers.IO) {
                sendSshCommand(25, value)
            }
        }

    }

    private suspend fun sendSshCommand(pinNumber: Int, value: String) {
        sshConnectionMutex.withLock { // mutex lock to ensure thread-safety
            if (sshConnection == null || !sshConnection!!.isConnected()) { // check if sshConnection is not already created or connected
                sshConnection = SshConnection(AppGlobals.ipAddress, AppGlobals.hostName, AppGlobals.password) // create sshConnection instance
                sshConnection?.connect() // connect to the remote host
            }

            if (sshConnection == null || !sshConnection!!.isConnected()) { // check if sshConnection is not connected
                sshConnection?.closeSession() // close existing sshConnection
                sshConnection = SshConnection(AppGlobals.ipAddress, AppGlobals.hostName, AppGlobals.password) // create sshConnection instance
                sshConnection?.connect() // connect to the remote host
            }

            // Check session status before executing command
            if (sshConnection != null && sshConnection!!.isConnected()) {
                when (value) { // check the value to perform the action
                    "on" -> sshConnection?.executeCommand("raspi-gpio set $pinNumber $COMMAND_ON") // execute the command to turn ON
                    "off" -> sshConnection?.executeCommand("raspi-gpio set $pinNumber $COMMAND_OFF") // execute the command to turn OFF
                    else -> {} // do nothing for any other value
                }
            } else {
                // Handle session not connected error
                Log.e(TAG, "SSH session not connected")
            }
        }
    }

    // Starts the updates loop, which fetches sensor values at a fixed interval
    private fun startUpdates() {
        val interval = 500L // 0.5 second

        // Launches a coroutine in the IO context
        job = lifecycleScope.launch(Dispatchers.IO) {
            // Connects to the remote SSH server
            SshManager.connect()

            // Enters a loop that runs as long as the coroutine is active
            while (isActive) {
                // Updates the sensor values by calling the `updateSensorValues` function of the `SshManager` object
                SshManager.updateSensorValues()

                // Delays the coroutine for a fixed interval
                delay(interval)
            }

            // Disconnects from the remote SSH server
            SshManager.disconnect()
        }
    }

    // Cancels the updates loop when the fragment is paused
    override fun onPause() {
        super.onPause()
        job?.cancel()
        job = null
    }

    // Starts the updates loop when the fragment is resumed
    override fun onResume() {
        super.onResume()
        if (AppGlobals.hostName.isNotEmpty() && AppGlobals.ipAddress.isNotEmpty() && AppGlobals.password.isNotEmpty()) {
            startUpdates()
        }
    }

    // Closes the SSH session and cleans up the binding when the fragment view is destroyed
    override fun onDestroyView() {
        super.onDestroyView()
        sshConnection?.closeSession()
        sshConnection = null
        _binding = null
    }

}

object SshManager {
    private var ssh: SshConnection? = null // Initialize SSH connection as null
    private var connected = false

    // Connect to the SSH server if not already connected
    fun connect() {
        if (!connected) {
            ssh = SshConnection(AppGlobals.ipAddress, AppGlobals.hostName, AppGlobals.password)
            ssh?.connect()
            connected = true
        } else if (ssh?.isConnected() != true) {
            ssh?.connect()
        }
    }


    // Disconnect from the SSH server if connected
    fun disconnect() {
        if (connected) {
            ssh?.closeSession()
            connected = false
        }
    }

    // Update sensor values using coroutines
    suspend fun updateSensorValues() {
        // Check if SSH connection is initialized
        val sensorUpdater = SensorUpdater(ssh ?: throw IllegalStateException("SSH not connected"), homeViewModel)

        parallelTasks(
            { sensorUpdater.updateTemperatureHumidity() },
            { sensorUpdater.updateLight1() },
            { sensorUpdater.updateLight2() },
            { sensorUpdater.updateLight3() },
            { sensorUpdater.updateLight4() },
            { sensorUpdater.updateAC() },
            { sensorUpdater.updateGasSensor() },
            { sensorUpdater.updateProximitySensor() }
        )
    }

    private suspend fun <T> parallelTasks(vararg tasks: suspend () -> T) {
        withContext(Dispatchers.IO) {
            tasks.map { async { it() } }.awaitAll()
        }
    }
}



