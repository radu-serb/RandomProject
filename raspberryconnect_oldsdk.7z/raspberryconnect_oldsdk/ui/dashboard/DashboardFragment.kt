package com.example.raspberryconnect_oldsdk.ui.dashboard

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.ViewModelProvider
import com.example.raspberryconnect_oldsdk.AppGlobals
import com.example.raspberryconnect_oldsdk.databinding.FragmentDashboardBinding


class DashboardFragment : Fragment() {

    private var _binding: FragmentDashboardBinding? = null

    // This property is only valid between onCreateView and
    // onDestroyView.
    private val binding get() = _binding!!
    private lateinit var configButton: Button
    private lateinit var  deviceNameEditText: EditText
    private lateinit var  hostNameEditText: EditText
    private lateinit var  ipAddressEditText: EditText
    private lateinit var  passwordEditText: EditText

    override fun onCreateView(
        inflater: LayoutInflater,
        container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val dashboardViewModel =
            ViewModelProvider(this)[DashboardViewModel::class.java]

        _binding = FragmentDashboardBinding.inflate(inflater, container, false)
        val root: View = binding.root

        val textView: TextView = binding.textView
        dashboardViewModel.text.observe(viewLifecycleOwner) {
            textView.text = it
        }

        configButton = binding.configButton
        deviceNameEditText = binding.deviceName
        hostNameEditText = binding.hostname
        ipAddressEditText = binding.ipAddress
        passwordEditText = binding.password

        configButton.setOnClickListener {
            AppGlobals.deviceName = deviceNameEditText.text?.toString() ?: ""
            AppGlobals.hostName = hostNameEditText.text?.toString() ?: ""
            AppGlobals.ipAddress = ipAddressEditText.text?.toString() ?: ""
            AppGlobals.password = passwordEditText.text?.toString() ?: ""
            AppGlobals.saveGlobals()

            if (AppGlobals.hostName.isBlank() || AppGlobals.ipAddress.isBlank() || AppGlobals.password.isBlank()) {
                Toast.makeText(requireContext(), "Please enter all required fields", Toast.LENGTH_LONG).show()
                return@setOnClickListener
            }
        }

        return root
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }
}