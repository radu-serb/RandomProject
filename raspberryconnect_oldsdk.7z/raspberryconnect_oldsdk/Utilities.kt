package com.example.raspberryconnect_oldsdk

import android.content.Context
import android.content.SharedPreferences
import androidx.core.content.edit
import com.example.raspberryconnect_oldsdk.ui.home.HomeViewModel
import com.jcraft.jsch.ChannelExec
import com.jcraft.jsch.JSch
import com.jcraft.jsch.JSchException
import com.jcraft.jsch.Session
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.SocketException
import java.util.concurrent.ConcurrentHashMap

object PreferencesKeys {
    const val DEVICE_NAME = "device_name"
    const val HOST_NAME = "host_name"
    const val IP_ADDRESS = "ip_address"
    const val PASSWORD = "password"
    const val DATA_BUFFER_TEXT = "databuffertext"
    const val DATA_BUFFER = "databuffer"
}

object AppGlobals {
    private const val PREFS_NAME = "RaspberryConnectPrefs"
    private lateinit var preferences: SharedPreferences

    var deviceName = ""
    var hostName = ""
    var ipAddress = ""
    var password = ""
    private var databuffertext = ""
    private var databuffer = false

    fun init(context: Context) {
        preferences = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        deviceName = preferences.getString(PreferencesKeys.DEVICE_NAME, "")!!
        hostName = preferences.getString(PreferencesKeys.HOST_NAME, "")!!
        ipAddress = preferences.getString(PreferencesKeys.IP_ADDRESS, "")!!
        password = preferences.getString(PreferencesKeys.PASSWORD, "")!!
        databuffertext = preferences.getString(PreferencesKeys.DATA_BUFFER_TEXT, "")!!
        databuffer = preferences.getBoolean(PreferencesKeys.DATA_BUFFER, false)
    }

    fun saveGlobals() {
        preferences.edit {
            putString(PreferencesKeys.DEVICE_NAME, deviceName)
            putString(PreferencesKeys.HOST_NAME, hostName)
            putString(PreferencesKeys.IP_ADDRESS, ipAddress)
            putString(PreferencesKeys.PASSWORD, password)
            putString(PreferencesKeys.DATA_BUFFER_TEXT, databuffertext)
            putBoolean(PreferencesKeys.DATA_BUFFER, databuffer)
        }
    }
}

class SshConnection(host: String, username: String, private val password: String) {

    private val session: Session = JSch().getSession(username, host, 22)

    init {
        session.setConfig("StrictHostKeyChecking", "no")
    }

    fun isConnected(): Boolean {
        return session.isConnected
    }

    fun connect() {
        if (!session.isConnected) {
            session.setPassword(password)
            session.timeout = 60000 // 1 minute
            var retryCount = 0
            var isConnected = false
            while (!isConnected && retryCount < 3) {
                try {
                    session.connect()
                    isConnected = true
                } catch (e: JSchException) {
                    if (e.cause is SocketException) {
                        retryCount++
                        Thread.sleep(1000)
                    } else {
                        e.printStackTrace()
                        break
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                    break
                }
            }
        }
    }

    suspend fun executeCommand(command: String): String = withContext(Dispatchers.IO) {
        (session.openChannel("exec") as ChannelExec).run {
            setCommand(command)
            connect()

            BufferedReader(InputStreamReader(inputStream), 8192).use { reader ->
                return@run reader.readText().trim()
            }
        }
    }


    fun closeSession() {
        session.disconnect()
    }
}


class SensorUpdater(private val ssh: SshConnection, private val homeViewModel: HomeViewModel) {
    private val sensorCache = ConcurrentHashMap<String, String>()

    private suspend fun executeCachedCommand(command: String, cacheKey: String): String {
        return sensorCache.getOrPut(cacheKey) {
            withContext(Dispatchers.IO) {
                ssh.executeCommand(command)
            }
        }
    }

    private suspend fun updateSensorValue(cacheKey: String, command: String, pattern: Regex, updateFunction: suspend (Int) -> Unit) {
        val status = executeCachedCommand(command, cacheKey)
        pattern.find(status)?.let {
            val statusG = it.groupValues[1].toInt()
            updateFunction(statusG)
        }
    }

    private suspend fun updateTemperatureHumidityValue(cacheKey: String, command: String, updateFunction: suspend (String, String) -> Unit) {
        val status = executeCachedCommand(command, cacheKey)
        val pattern = Regex(".*?\\((\\d+\\.\\d+),\\s*(\\d+\\.\\d+)\\)")
        pattern.find(status)?.let {
            val humidity = it.groupValues[1]
            val temperature = it.groupValues[2]
            updateFunction(humidity, temperature)
        }
    }

    suspend fun updateTemperatureHumidity() {
        val cacheKey = "temperature"
        val command = "python PythonProject/Get_DHT11.py 7"

        updateTemperatureHumidityValue(cacheKey, command) { humidity, temperature ->
            withContext(Dispatchers.Main) {
                homeViewModel.updateSenzortemperaturaText(temperature)
                homeViewModel.updateSenzorumiditateText(humidity)
            }
        }
    }

    suspend fun updateLight1() {
        val cacheKey = "light1"
        val command = "raspi-gpio get 21"
        val pattern = Regex("GPIO 21: level=(\\d) fsel=1 func=OUTPUT")

        updateSensorValue(cacheKey, command, pattern) { level ->
            coroutineScope {
                launch(Dispatchers.Main) {
                    homeViewModel.updateLumina1SwitchState(level == 1)
                }
            }
        }
    }

    suspend fun updateLight2() {
        val cacheKey = "light2"
        val command = "raspi-gpio get 20"
        val pattern = Regex("GPIO 20: level=(\\d) fsel=1 func=OUTPUT")

        updateSensorValue(cacheKey, command, pattern) { level ->
            coroutineScope {
                launch(Dispatchers.Main) {
                    homeViewModel.updateLumina2SwitchState(level == 1)
                }
            }
        }
    }

    suspend fun updateLight3() {
        val cacheKey = "light3"
        val command = "raspi-gpio get 16"
        val pattern = Regex("GPIO 16: level=(\\d) fsel=1 func=OUTPUT")

        updateSensorValue(cacheKey, command, pattern) { level ->
            coroutineScope {
                launch(Dispatchers.Main) {
                    homeViewModel.updateLumina3SwitchState(level == 1)
                }
            }
        }
    }

    suspend fun updateLight4() {
        val cacheKey = "light4"
        val command = "raspi-gpio get 12"
        val pattern = Regex("GPIO 12: level=(\\d) fsel=1 func=OUTPUT")

        updateSensorValue(cacheKey, command, pattern) { level ->
            coroutineScope {
                launch(Dispatchers.Main) {
                    homeViewModel.updateLumina4SwitchState(level == 1)
                }
            }
        }
    }

    suspend fun updateAC() {
        val cacheKey = "ac"
        val command = "raspi-gpio get 1"
        val pattern = Regex("GPIO 1: level=(\\d) fsel=1 func=OUTPUT")

        updateSensorValue(cacheKey, command, pattern) { level ->
            coroutineScope {
                launch(Dispatchers.Main) {
                    homeViewModel.updateAerconditionatSwitchState(level == 1)
                }
            }
        }
    }

    suspend fun updateGasSensor() {
        val cacheKey = "gasSensor"
        val command = "raspi-gpio get 25"
        val pattern = Regex("GPIO 25: level=(\\d) fsel=1 func=OUTPUT")

        updateSensorValue(cacheKey, command, pattern) { statusG ->
            coroutineScope {
                launch(Dispatchers.Main) {
                    homeViewModel.updateSenzorgazSwitchState(statusG == 0)
                    homeViewModel.updateSenzorgazText(if (statusG == 0) "Alarma Gaz ACTIVATA" else "Alarma Gaz DEZACTIVATA")
                }
            }
        }
    }

    suspend fun updateProximitySensor() {
        val cacheKey = "proximitySensor"
        val command = "raspi-gpio get 23"
        val pattern = Regex("GPIO 23: level=(\\d) fsel=1 func=OUTPUT")

        updateSensorValue(cacheKey, command, pattern) { statusG ->
            coroutineScope {
                launch(Dispatchers.Main) {
                    homeViewModel.updateSenzorproximitateText(if (statusG == 1) "Alarma Locuinta ACTIVATA" else "Alarma Locuinta DEZACTIVATA")
                }
            }
        }
    }
}

